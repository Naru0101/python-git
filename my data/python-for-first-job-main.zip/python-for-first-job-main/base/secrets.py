import os


TOKEN = os.getenv('TOKEN')  # Токен телеграм-бота
CHAT_ID = os.getenv('CHAT_ID')  # Айди чата, где находится телеграм-бот
